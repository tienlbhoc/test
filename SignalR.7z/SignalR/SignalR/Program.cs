﻿using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Console.Write("Url:");
        string url = Console.ReadLine() ?? "";
        Console.Write("ReceiveMessage:");
        string msg = Console.ReadLine() ?? "";

        var connection = new HubConnectionBuilder()
            .WithUrl(url)
            .WithAutomaticReconnect()
            .ConfigureLogging(logging =>
            {
                // Log to the Console
                logging.AddDebug();

                // This will set ALL logging to Debug level
                logging.SetMinimumLevel(LogLevel.Debug);
            })
            .Build();

        connection.On<string, string>(msg, (user, message) =>
        {
            Console.WriteLine($"{user}: {message}");
        });

        await connection.StartAsync();

        Console.WriteLine("Connected to SignalR Hub.");

        while (true)
        {
            var message = Console.ReadLine();
            await connection.InvokeAsync("SendMessage", "ConsoleApp", message);
        }
    }
}
